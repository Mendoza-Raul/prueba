public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('email')->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->boolean('tipo_usuario')->default(0); // 0 = suscriptor && 1 = administrador
            $table->rememberToken();
            $table->timestamps();
        });
    }